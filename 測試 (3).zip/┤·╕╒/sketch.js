function setup() {
  createCanvas(500,400);
}

function draw() {
  background(208,193,198);
  noFill()
  stroke(255)
  rectMode(CENTER)
  strokeWeight(2)

  
  var r = mouseX;
  
  
  for(var i =0;i<12;i++)
  {
  ellipse(25+i*50,25,r)
  rect(25+i*50,25,r)
}
  for(var i =0;i<12;i++)
  {
  ellipse(i*50,50,r)
}

for(var i =0;i<12;i++)
  {
  ellipse(i*50,50,r)
}

ellipse(25,75,r)
rectMode(CENTER)
  rect(25,75,r)
  ellipse(50,100,r)

  for(var i =0;i<12;i++)
  {
  ellipse(25+i*50,75,r)
  rect(25+i*50,75,r)
}
  for(var i =0;i<12;i++)
  {
  ellipse(i*50,200,r)
}

ellipse(25,125,r)
rectMode(CENTER)
  rect(25,125,r)
  ellipse(50,150,r)
  
  for(var i =0;i<12;i++)
  {
  ellipse(25+i*50,125,r)
  rect(25+i*50,125,r)
}
  for(var i =0;i<12;i++)
  {
  ellipse(i*50,150,r)
}
for(var i =0;i<12;i++)
  {
  ellipse(i*50,50,r)
}
ellipse(25,175,r)
rectMode(CENTER)
  rect(25,175,r)
  ellipse(50,200,r)

  for(var i =0;i<12;i++)
  {
  ellipse(25+i*50,175,r)
  rect(25+i*50,175,r)
}
  for(var i =0;i<12;i++)
  {
  ellipse(i*50,200,r)
}


ellipse(25,225,r)
rectMode(CENTER)
  rect(25,225,r)
  ellipse(50,250,r)

  for(var i =0;i<12;i++)
  {
  ellipse(25+i*50,225,r)
  rect(25+i*50,225,r)
}
  for(var i =0;i<12;i++)
  {
  ellipse(i*50,250,r)
}

for(var i =0;i<12;i++)
  {
  ellipse(i*50,100,r)
}

ellipse(25,275,r)
rectMode(CENTER)
  rect(25,275,r)
  ellipse(50,300,r)

  for(var i =0;i<12;i++)
  {
  ellipse(25+i*50,275,r)
  rect(25+i*50,275,r)
}
  for(var i =0;i<12;i++)
  {
  ellipse(i*50,300,r)
}
for(var i =0;i<12;i++)
  {
  ellipse(i*50,200,r)
}
ellipse(25,325,r)
rectMode(CENTER)
  rect(25,325,r)
  ellipse(50,350,r)

  for(var i =0;i<12;i++)
  {
  ellipse(25+i*50,325,r)
  rect(25+i*50,325,r)
}
  for(var i =0;i<12;i++)
  {
  ellipse(i*50,350,r)
}

ellipse(25,375,r)
rectMode(CENTER)
  rect(25,375,r)
  ellipse(50,400,r)

  

  for(var i =0;i<12;i++)
  {
  ellipse(25+i*50,375,r)
  rect(25+i*50,375,r)
}
  for(var i =0;i<12;i++)
  {
  ellipse(i*50,400,r)
}
 
for(var i =0;i<12;i++)
  {
  ellipse(i*50,350,r)
}

  
}
